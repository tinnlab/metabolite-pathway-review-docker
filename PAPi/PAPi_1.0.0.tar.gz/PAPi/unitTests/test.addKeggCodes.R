{\rtf1\ansi\ansicpg1252\cocoartf1138\cocoasubrtf510
{\fonttbl\f0\fnil\fcharset0 Menlo-Regular;}
{\colortbl;\red255\green255\blue255;}
\margl1440\margr1440\vieww10800\viewh8400\viewkind0
\deftab560
\pard\tx560\pardeftab560\pardirnatural

\f0\fs22 \cf0 \CocoaLigature0 test.addKeggCodes <- function() \{\
    exampleMetabData <- data(metabolomicsData)\
    exampleKeggLib <- data(keggLibrary)\
    testResults <- addKeggCodes(exampleMetabData, exampleKeggLib, save = FALSE, addCodes = FALSE)\
\}}